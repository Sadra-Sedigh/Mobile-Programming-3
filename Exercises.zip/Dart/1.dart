void main() {
  String productName = "Laptop";
  double price = 45000000;
  int quantity = 2;
  String brand = "Asus";

  print("Product Name: $productName");
  print("Price: $price");
  print("Quantity: $quantity");
  print("Brand: $brand");
}
