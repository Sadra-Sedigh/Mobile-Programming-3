void main() {
  List<double> prices = [100, 250, 500, 700, 900];

  double limit = 400;

  List<double> result = getPrices(prices, limit);

  double total = calculateSum(result);

  print("Prices above limit: $result");
  print("Total: $total");
}

List<double> getPrices(List<double> prices, double limit) {
  return prices.where((price) => price > limit).toList();
}

double calculateSum(List<double> prices) {
  double sum = 0;

  for (var price in prices) {
    sum += price;
  }

  return sum;
}
