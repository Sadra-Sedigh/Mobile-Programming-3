void main() {
  String priceString = "500000";
  String discountString = "20";

  double price = double.parse(priceString);
  double discount = double.parse(discountString);

  double discountAmount = price * discount / 100;
  double finalPrice = price - discountAmount;

  print("Original Price: $price");
  print("Discount: $discount%");
  print("Discount Amount: $discountAmount");
  print("Final Price: $finalPrice");
}