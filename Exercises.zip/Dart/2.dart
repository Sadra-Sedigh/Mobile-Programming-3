void main() {
  // var
  var name = "Parsa";
  name = "Ali";

  print(name);

  // final
  final age = 21;
  print(age);

  // const
  const pi = 3.14;
  print(pi);
}