void main() {
  List<String> shoppingList = [
    "Milk",
    "Bread",
    "Eggs",
  ];

  shoppingList.remove("Bread");

  shoppingList.add("Cheese");

  print(shoppingList);

  print("Final Count: ${shoppingList.length}");
}
